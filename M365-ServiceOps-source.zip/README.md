# M365 ServiceOps Command Center

A portfolio-grade IT service management and major-incident platform built for Microsoft 365 service operations. It combines ticketing, SLA automation, recurring-incident analysis, major incidents, change/CAB workflows, simulated Microsoft 365 administration, infrastructure monitoring, a knowledge base, RBAC, and immutable audit history.

## Quick start

```bash
cp .env.example .env
docker compose up --build
```

Open `http://localhost:3000`. Demo credentials:

| Role | Email | Password |
|---|---|---|
| Administrator | admin@contoso.demo | Demo123! |
| Service Desk | analyst@contoso.demo | Demo123! |
| Change Manager | change@contoso.demo | Demo123! |
| Viewer | viewer@contoso.demo | Demo123! |

Swagger is at `http://localhost:8080/swagger`; health is at `http://localhost:8080/health`.

See [`docs/COMPLETE-PROJECT-GUIDE.md`](docs/COMPLETE-PROJECT-GUIDE.md) for the architecture, every feature, every function, file connections, security model, API reference, troubleshooting, and interview demonstration script.

> This application simulates Microsoft Graph operations. It never modifies a real Microsoft 365 tenant. The `IGraphSimulationService` abstraction is the safe extension point for a production Graph adapter.

