<#
.SYNOPSIS
Authenticates to the local ServiceOps API and returns a reusable session object.
.DESCRIPTION
Sends demo credentials to the authentication endpoint. The returned object contains
the bearer token and headers required by the remaining support-automation scripts.
#>
[CmdletBinding()]
param(
  [string]$ApiUrl = "http://localhost:8080",
  [string]$Email = "analyst@contoso.demo",
  [securestring]$Password
)

if (-not $Password) { $Password = ConvertTo-SecureString "Demo123!" -AsPlainText -Force }
$credential = [pscredential]::new($Email, $Password)
$body = @{ email = $Email; password = $credential.GetNetworkCredential().Password } | ConvertTo-Json
$response = Invoke-RestMethod -Uri "$ApiUrl/api/auth/login" -Method Post -ContentType "application/json" -Body $body
[pscustomobject]@{
  ApiUrl = $ApiUrl
  User = $response.user
  Token = $response.token
  Headers = @{ Authorization = "Bearer $($response.token)" }
}
