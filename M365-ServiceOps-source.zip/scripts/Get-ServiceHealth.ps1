<# .SYNOPSIS Returns a concise infrastructure and alert health report. #>
[CmdletBinding()]
param([Parameter(Mandatory)][psobject]$Session, [switch]$Refresh)
if ($Refresh) { Invoke-RestMethod -Uri "$($Session.ApiUrl)/api/monitoring/simulate-poll" -Method Post -Headers $Session.Headers | Out-Null }
$resources = Invoke-RestMethod -Uri "$($Session.ApiUrl)/api/monitoring/resources" -Headers $Session.Headers
$alerts = Invoke-RestMethod -Uri "$($Session.ApiUrl)/api/monitoring/alerts" -Headers $Session.Headers
[pscustomobject]@{
  CheckedAt = Get-Date
  Healthy = @($resources | Where-Object status -eq "Healthy").Count
  Warning = @($resources | Where-Object status -eq "Warning").Count
  Critical = @($resources | Where-Object status -eq "Critical").Count
  UnacknowledgedAlerts = @($alerts | Where-Object acknowledged -eq $false).Count
  Resources = $resources
}
