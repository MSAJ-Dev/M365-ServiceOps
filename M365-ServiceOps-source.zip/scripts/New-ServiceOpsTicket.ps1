<#
.SYNOPSIS
Creates an ITSM incident through the ServiceOps API.
.EXAMPLE
$session = ./Connect-ServiceOps.ps1
./New-ServiceOpsTicket.ps1 -Session $session -Title "Outlook cannot connect" -Category "Exchange Online" -Priority P2 -Requester "user@contoso.demo" -Description "Desktop client disconnected."
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory)][psobject]$Session,
  [Parameter(Mandatory)][string]$Title,
  [Parameter(Mandatory)][string]$Description,
  [ValidateSet("Microsoft 365","Microsoft Teams","SharePoint","Exchange Online","Entra ID","Endpoint","Network")][string]$Category = "Microsoft 365",
  [ValidateSet("P1","P2","P3","P4")][string]$Priority = "P3",
  [Parameter(Mandatory)][ValidatePattern('^[^@]+@[^@]+\.[^@]+$')][string]$Requester
)
$body = @{ title=$Title; description=$Description; category=$Category; priority=$Priority; requesterEmail=$Requester } | ConvertTo-Json
Invoke-RestMethod -Uri "$($Session.ApiUrl)/api/tickets/" -Method Post -Headers $Session.Headers -ContentType "application/json" -Body $body
