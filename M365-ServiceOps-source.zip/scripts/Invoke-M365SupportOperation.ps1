<#
.SYNOPSIS
Runs a safe, simulated Microsoft Graph support operation.
.DESCRIPTION
This script intentionally calls the local simulation API. It does not import the
Microsoft Graph module and cannot modify a live tenant.
#>
[CmdletBinding(SupportsShouldProcess)]
param(
  [Parameter(Mandatory)][psobject]$Session,
  [Parameter(Mandatory)][guid]$DirectoryUserId,
  [Parameter(Mandatory)][ValidateSet("reset-password","enable","disable","add-group","remove-group","assign-licence","remove-licence")][string]$Operation,
  [string]$Value
)
if ($PSCmdlet.ShouldProcess($DirectoryUserId, "$Operation (simulation)")) {
  $body = @{ operation=$Operation; value=$Value } | ConvertTo-Json
  Invoke-RestMethod -Uri "$($Session.ApiUrl)/api/directory/users/$DirectoryUserId/operations" -Method Post -Headers $Session.Headers -ContentType "application/json" -Body $body
}
