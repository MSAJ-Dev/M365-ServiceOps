using Microsoft.EntityFrameworkCore;
using ServiceOps.Api.Data;
using ServiceOps.Api.Domain;
using ServiceOps.Api.Services;

namespace ServiceOps.Tests;

public sealed class CoreServicesTests
{
    private static AppDbContext Database() => new(new DbContextOptionsBuilder<AppDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options);

    [Theory]
    [InlineData(TicketPriority.P1, 0.25, 4)]
    [InlineData(TicketPriority.P2, 1, 8)]
    [InlineData(TicketPriority.P3, 4, 24)]
    [InlineData(TicketPriority.P4, 8, 72)]
    public void Calculate_ReturnsPriorityTargets(TicketPriority priority, double responseHours, double resolutionHours)
    {
        using var db = Database(); var service = new SlaService(db); var start = DateTimeOffset.Parse("2026-08-08T12:00:00Z");
        var result = service.Calculate(priority, start);
        Assert.Equal(start.AddHours(responseHours), result.response);
        Assert.Equal(start.AddHours(resolutionHours), result.resolution);
    }

    [Fact]
    public async Task EscalateBreachesAsync_FlagsOnlyOpenOverdueTickets()
    {
        await using var db = Database(); var service = new SlaService(db);
        db.Tickets.AddRange(Ticket(DateTimeOffset.UtcNow.AddMinutes(-1), false), Ticket(DateTimeOffset.UtcNow.AddHours(1), false), Ticket(DateTimeOffset.UtcNow.AddMinutes(-1), true));
        await db.SaveChangesAsync();
        Assert.Equal(1, await service.EscalateBreachesAsync(default));
        Assert.Equal(1, await db.Tickets.CountAsync(x => x.Escalated));
    }

    [Theory]
    [InlineData("Teams calls dropping!", "calls-dropping-teams")]
    [InlineData("My SharePoint access is not working", "access-sharepoint-working")]
    public void Fingerprint_NormalizesAndSortsTerms(string input, string expected) => Assert.Equal(expected, IncidentAnalyticsService.Fingerprint(input));

    [Fact]
    public void Overlaps_DetectsConflictButNotAdjacentWindows()
    {
        var start = DateTimeOffset.UtcNow;
        Assert.True(ChangeConflictDetector.Overlaps(start, start.AddHours(2), start.AddHours(1), start.AddHours(3)));
        Assert.False(ChangeConflictDetector.Overlaps(start, start.AddHours(2), start.AddHours(2), start.AddHours(3)));
    }

    private static Ticket Ticket(DateTimeOffset due, bool resolved) => new() { Number = Guid.NewGuid().ToString(), Title = "test", Description = "test", Category = "test", Priority = TicketPriority.P3, Status = resolved ? TicketStatus.Resolved : TicketStatus.New, RequesterEmail = "test@example.com", ResponseDueAt = due, ResolutionDueAt = due, ResolvedAt = resolved ? DateTimeOffset.UtcNow : null };
}
