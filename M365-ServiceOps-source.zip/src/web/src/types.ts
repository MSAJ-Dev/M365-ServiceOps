export type User = { id: string; displayName: string; email: string; role: string };
export type Ticket = { id: string; number: string; title: string; description: string; category: string; priority: string; status: string; requesterEmail: string; responseDueAt: string; resolutionDueAt: string; escalated: boolean; assignee?: User; createdAt: string };
export type MajorIncident = { id: string; number: string; title: string; service: string; severity: string; status: string; commander: string; businessImpact: string; startedAt: string; updates: { id: string; status: string; message: string; author: string; createdAt: string }[] };
export type Change = { id: string; number: string; title: string; type: string; risk: string; impact: string; status: string; owner: string; plannedStart: string; plannedEnd: string; rollbackPlan: string };
export type DirectoryUser = { id: string; displayName: string; userPrincipalName: string; accountEnabled: boolean; passwordResetRequired: boolean; groups: string[]; licences: string[] };
export type Resource = { id: string; name: string; resourceType: string; environment: string; status: string; cpuPercent: number; memoryPercent: number; latencyMs: number; lastCheckedAt: string };
export type Article = { id: string; title: string; summary: string; content: string; category: string; tags: string; author: string; views: number };
