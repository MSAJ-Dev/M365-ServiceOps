const base = import.meta.env.VITE_API_URL ?? '';
let token = localStorage.getItem('serviceops_token');

export function setToken(value: string | null) { token = value; value ? localStorage.setItem('serviceops_token', value) : localStorage.removeItem('serviceops_token'); }
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${base}${path}`, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers } });
  if (response.status === 401) { setToken(null); window.dispatchEvent(new Event('serviceops:unauthorized')); throw new Error('Your session expired.'); }
  if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.error ?? body.title ?? `Request failed (${response.status})`); }
  return response.status === 204 ? (undefined as T) : response.json();
}
export const formatAge = (date: string) => { const minutes = Math.floor((Date.now() - new Date(date).getTime()) / 60000); return minutes < 60 ? `${minutes}m` : minutes < 1440 ? `${Math.floor(minutes / 60)}h` : `${Math.floor(minutes / 1440)}d`; };
export const formatDate = (date: string) => new Intl.DateTimeFormat('en-CA', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(date));
