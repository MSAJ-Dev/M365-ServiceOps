using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ServiceOps.Api.Contracts;
using ServiceOps.Api.Data;
using ServiceOps.Api.Domain;
using ServiceOps.Api.Services;

namespace ServiceOps.Api.Endpoints;

public static class ApiEndpoints
{
    public static IEndpointRouteBuilder MapServiceOpsApi(this IEndpointRouteBuilder app)
    {
        app.MapAuth();
        app.MapDashboard();
        app.MapTickets();
        app.MapMajorIncidents();
        app.MapChanges();
        app.MapDirectory();
        app.MapMonitoring();
        app.MapKnowledge();
        app.MapAudit();
        return app;
    }

    private static void MapAuth(this IEndpointRouteBuilder app)
    {
        app.MapPost("/api/auth/login", async (LoginRequest request, AppDbContext db, ITokenService tokens) =>
        {
            var user = await db.Users.SingleOrDefaultAsync(x => x.Email == request.Email && x.IsActive);
            if (user is null) return Results.Unauthorized();
            var valid = new PasswordHasher<AppUser>().VerifyHashedPassword(user, user.PasswordHash, request.Password);
            if (valid == PasswordVerificationResult.Failed) return Results.Unauthorized();
            return Results.Ok(new { token = tokens.Create(user), user = new { user.Id, user.DisplayName, user.Email, user.Role } });
        }).AllowAnonymous().WithTags("Authentication");
    }

    private static void MapDashboard(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/dashboard", async (AppDbContext db) =>
        {
            var now = DateTimeOffset.UtcNow;
            var open = await db.Tickets.CountAsync(x => x.Status != TicketStatus.Resolved && x.Status != TicketStatus.Closed);
            var breached = await db.Tickets.CountAsync(x => x.ResolvedAt == null && x.ResolutionDueAt < now);
            var resolved = await db.Tickets.Where(x => x.ResolvedAt != null).ToListAsync();
            var mttr = resolved.Count == 0 ? 0 : resolved.Average(x => (x.ResolvedAt!.Value - x.CreatedAt).TotalHours);
            var slaMet = await db.Tickets.CountAsync(x => (x.ResolvedAt != null && x.ResolvedAt <= x.ResolutionDueAt) || (x.ResolvedAt == null && now <= x.ResolutionDueAt));
            var total = await db.Tickets.CountAsync();
            var byCategory = await db.Tickets.GroupBy(x => x.Category).Select(g => new { name = g.Key, value = g.Count() }).OrderByDescending(x => x.value).ToListAsync();
            var recent = await db.Tickets.OrderByDescending(x => x.CreatedAt).Take(5).ToListAsync();
            return Results.Ok(new { openTickets = open, p1Tickets = await db.Tickets.CountAsync(x => x.Priority == TicketPriority.P1 && x.ResolvedAt == null), activeMajorIncidents = await db.MajorIncidents.CountAsync(x => x.ResolvedAt == null), slaCompliance = total == 0 ? 100 : Math.Round(100d * slaMet / total, 1), mttrHours = Math.Round(mttr, 1), breachedTickets = breached, criticalResources = await db.Resources.CountAsync(x => x.Status == MonitorStatus.Critical), byCategory, recent });
        }).RequireAuthorization().WithTags("Dashboard");
    }

    private static void MapTickets(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/tickets").RequireAuthorization().WithTags("Tickets");
        group.MapGet("/", async (string? status, string? search, AppDbContext db) =>
        {
            var query = db.Tickets.Include(x => x.Assignee).AsQueryable();
            if (Enum.TryParse<TicketStatus>(status, true, out var parsed)) query = query.Where(x => x.Status == parsed);
            if (!string.IsNullOrWhiteSpace(search)) query = query.Where(x => x.Number.Contains(search) || x.Title.ToLower().Contains(search.ToLower()));
            return await query.OrderBy(x => x.Status).ThenBy(x => x.Priority).ThenByDescending(x => x.CreatedAt).ToListAsync();
        });
        group.MapGet("/{id:guid}", async (Guid id, AppDbContext db) => await db.Tickets.Include(x => x.Assignee).Include(x => x.Comments).SingleOrDefaultAsync(x => x.Id == id) is { } ticket ? Results.Ok(ticket) : Results.NotFound());
        group.MapPost("/", async (CreateTicketRequest request, AppDbContext db, ISlaService sla, IAuditService audit, ClaimsPrincipal principal, HttpContext http) =>
        {
            var created = DateTimeOffset.UtcNow;
            var deadlines = sla.Calculate(request.Priority, created);
            var next = await db.Tickets.CountAsync() + 1001;
            var ticket = new Ticket { Number = $"INC-{next}", Title = request.Title, Description = request.Description, Category = request.Category, Priority = request.Priority, Status = TicketStatus.New, RequesterEmail = request.RequesterEmail, ResponseDueAt = deadlines.response, ResolutionDueAt = deadlines.resolution, Fingerprint = IncidentAnalyticsService.Fingerprint(request.Title + " " + request.Description) };
            db.Tickets.Add(ticket); await db.SaveChangesAsync();
            await audit.RecordAsync(principal, "TicketCreated", nameof(Ticket), ticket.Id, ticket.Number, http.Connection.RemoteIpAddress?.ToString() ?? "");
            return Results.Created($"/api/tickets/{ticket.Id}", ticket);
        }).RequireAuthorization("Operator");
        group.MapPut("/{id:guid}", async (Guid id, UpdateTicketRequest request, AppDbContext db, IAuditService audit, ClaimsPrincipal principal, HttpContext http) =>
        {
            var ticket = await db.Tickets.FindAsync(id); if (ticket is null) return Results.NotFound();
            ticket.Status = request.Status; ticket.AssigneeId = request.AssigneeId; ticket.Resolution = request.Resolution;
            if (request.Status == TicketStatus.InProgress && ticket.FirstRespondedAt is null) ticket.FirstRespondedAt = DateTimeOffset.UtcNow;
            if (request.Status is TicketStatus.Resolved or TicketStatus.Closed) ticket.ResolvedAt ??= DateTimeOffset.UtcNow;
            await db.SaveChangesAsync(); await audit.RecordAsync(principal, "TicketUpdated", nameof(Ticket), id, request.Status.ToString(), http.Connection.RemoteIpAddress?.ToString() ?? "");
            return Results.Ok(ticket);
        }).RequireAuthorization("Operator");
        group.MapPost("/{id:guid}/comments", async (Guid id, AddCommentRequest request, AppDbContext db, IAuditService audit, ClaimsPrincipal principal, HttpContext http) =>
        {
            if (!await db.Tickets.AnyAsync(x => x.Id == id)) return Results.NotFound();
            var comment = new TicketComment { TicketId = id, Body = request.Body, IsInternal = request.IsInternal, Author = principal.Identity?.Name ?? "Unknown" };
            db.TicketComments.Add(comment); await db.SaveChangesAsync(); await audit.RecordAsync(principal, "CommentAdded", nameof(Ticket), id, request.IsInternal ? "Internal work note" : "Customer-visible comment", http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Ok(comment);
        }).RequireAuthorization("Operator");
        group.MapGet("/analytics/recurring", async (IIncidentAnalyticsService analytics) => Results.Ok(await analytics.DetectRecurringAsync()));
    }

    private static void MapMajorIncidents(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/major-incidents").RequireAuthorization().WithTags("Major Incidents");
        group.MapGet("/", async (AppDbContext db) => await db.MajorIncidents.Include(x => x.Updates).OrderByDescending(x => x.StartedAt).ToListAsync());
        group.MapPost("/", async (CreateIncidentRequest r, AppDbContext db, IAuditService audit, ClaimsPrincipal user, HttpContext http) => { var item = new MajorIncident { Number = $"MI-{DateTime.UtcNow:yyyy}-{await db.MajorIncidents.CountAsync() + 1:000}", Title = r.Title, Service = r.Service, Severity = r.Severity, BusinessImpact = r.BusinessImpact, Commander = r.Commander }; db.Add(item); await db.SaveChangesAsync(); await audit.RecordAsync(user, "MajorIncidentDeclared", nameof(MajorIncident), item.Id, item.Number, http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Created($"/api/major-incidents/{item.Id}", item); }).RequireAuthorization("Operator");
        group.MapPost("/{id:guid}/updates", async (Guid id, AddIncidentUpdateRequest r, AppDbContext db, IAuditService audit, ClaimsPrincipal user, HttpContext http) => { var incident = await db.MajorIncidents.FindAsync(id); if (incident is null) return Results.NotFound(); incident.Status = r.Status; if (r.Status.Equals("Resolved", StringComparison.OrdinalIgnoreCase)) incident.ResolvedAt = DateTimeOffset.UtcNow; var update = new IncidentUpdate { MajorIncidentId = id, Status = r.Status, Message = r.Message, CustomerVisible = r.CustomerVisible, Author = user.Identity?.Name ?? "Unknown" }; db.Add(update); await db.SaveChangesAsync(); await audit.RecordAsync(user, "IncidentUpdatePublished", nameof(MajorIncident), id, r.Status, http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Ok(update); }).RequireAuthorization("Operator");
    }

    private static void MapChanges(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/changes").RequireAuthorization().WithTags("Change and CAB");
        group.MapGet("/", async (AppDbContext db) => await db.Changes.Include(x => x.Approvals).OrderByDescending(x => x.PlannedStart).ToListAsync());
        group.MapGet("/conflicts", async (AppDbContext db) => { var items = await db.Changes.Where(x => x.Status != ChangeStatus.Rejected && x.Status != ChangeStatus.RolledBack).ToListAsync(); return items.SelectMany((a, i) => items.Skip(i + 1).Where(b => ChangeConflictDetector.Overlaps(a.PlannedStart, a.PlannedEnd, b.PlannedStart, b.PlannedEnd)).Select(b => new { first = a.Number, second = b.Number, start = a.PlannedStart > b.PlannedStart ? a.PlannedStart : b.PlannedStart })).ToList(); });
        group.MapPost("/", async (CreateChangeRequest r, AppDbContext db, IAuditService audit, ClaimsPrincipal user, HttpContext http) => { if (r.PlannedEnd <= r.PlannedStart) return Results.ValidationProblem(new Dictionary<string, string[]> { ["plannedEnd"] = ["Planned end must follow planned start."] }); var item = new ChangeRequest { Number = $"CHG-{await db.Changes.CountAsync() + 2001}", Title = r.Title, Type = r.Type, Risk = r.Risk, Impact = r.Impact, ImplementationPlan = r.ImplementationPlan, TestPlan = r.TestPlan, RollbackPlan = r.RollbackPlan, Owner = r.Owner, PlannedStart = r.PlannedStart, PlannedEnd = r.PlannedEnd, Status = ChangeStatus.Submitted }; db.Add(item); await db.SaveChangesAsync(); await audit.RecordAsync(user, "ChangeSubmitted", nameof(ChangeRequest), item.Id, item.Number, http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Created($"/api/changes/{item.Id}", item); }).RequireAuthorization("ChangeOperator");
        group.MapPost("/{id:guid}/decision", async (Guid id, DecideChangeRequest r, AppDbContext db, IAuditService audit, ClaimsPrincipal user, HttpContext http) => { var item = await db.Changes.FindAsync(id); if (item is null) return Results.NotFound(); var approval = new ChangeApproval { ChangeRequestId = id, Approver = user.Identity?.Name ?? "Unknown", Decision = r.Decision, Comment = r.Comment, DecidedAt = DateTimeOffset.UtcNow }; item.Status = r.Decision == ApprovalDecision.Approved ? ChangeStatus.Approved : ChangeStatus.Rejected; db.Add(approval); await db.SaveChangesAsync(); await audit.RecordAsync(user, "ChangeDecision", nameof(ChangeRequest), id, r.Decision.ToString(), http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Ok(item); }).RequireAuthorization("ChangeManager");
        app.MapGet("/api/cab-meetings", async (AppDbContext db) => await db.CabMeetings.OrderBy(x => x.ScheduledAt).ToListAsync()).RequireAuthorization().WithTags("Change and CAB");
    }

    private static void MapDirectory(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/directory").RequireAuthorization().WithTags("Microsoft Graph Simulation");
        group.MapGet("/users", async (string? search, AppDbContext db) => await db.DirectoryUsers.Where(x => string.IsNullOrWhiteSpace(search) || x.DisplayName.ToLower().Contains(search.ToLower()) || x.UserPrincipalName.ToLower().Contains(search.ToLower())).OrderBy(x => x.DisplayName).ToListAsync());
        group.MapPost("/users/{id:guid}/operations", async (Guid id, DirectoryOperationRequest request, IGraphSimulationService graph, IAuditService audit, ClaimsPrincipal user, HttpContext http) => { var result = await graph.ExecuteAsync(id, request.Operation, request.Value); await audit.RecordAsync(user, "GraphSimulation", nameof(DirectoryUser), id, $"{request.Operation}: {request.Value}", http.Connection.RemoteIpAddress?.ToString() ?? ""); return Results.Ok(result); }).RequireAuthorization("Operator");
    }

    private static void MapMonitoring(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/monitoring").RequireAuthorization().WithTags("Monitoring");
        group.MapGet("/resources", async (AppDbContext db) => await db.Resources.OrderByDescending(x => x.Status).ToListAsync());
        group.MapGet("/alerts", async (AppDbContext db) => await db.Alerts.OrderBy(x => x.Acknowledged).ThenByDescending(x => x.DetectedAt).ToListAsync());
        group.MapPost("/alerts/{id:guid}/acknowledge", async (Guid id, AppDbContext db) => { var alert = await db.Alerts.FindAsync(id); if (alert is null) return Results.NotFound(); alert.Acknowledged = true; await db.SaveChangesAsync(); return Results.Ok(alert); }).RequireAuthorization("Operator");
        group.MapPost("/simulate-poll", async (AppDbContext db) => { var random = new Random(); var items = await db.Resources.ToListAsync(); foreach (var x in items) { x.CpuPercent = Math.Clamp(x.CpuPercent + random.Next(-8, 9), 0, 100); x.MemoryPercent = Math.Clamp(x.MemoryPercent + random.Next(-5, 6), 0, 100); x.LatencyMs = Math.Max(1, x.LatencyMs + random.Next(-80, 81)); x.Status = x.CpuPercent > 90 || x.LatencyMs > 1200 ? MonitorStatus.Critical : x.CpuPercent > 75 || x.LatencyMs > 800 ? MonitorStatus.Warning : MonitorStatus.Healthy; x.LastCheckedAt = DateTimeOffset.UtcNow; } await db.SaveChangesAsync(); return Results.Ok(items); }).RequireAuthorization("Operator");
    }

    private static void MapKnowledge(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/knowledge").RequireAuthorization().WithTags("Knowledge Base");
        group.MapGet("/", async (string? q, AppDbContext db) => await db.Articles.Where(x => x.Published && (string.IsNullOrWhiteSpace(q) || x.Title.ToLower().Contains(q.ToLower()) || x.Summary.ToLower().Contains(q.ToLower()) || x.Tags.ToLower().Contains(q.ToLower()))).OrderByDescending(x => x.Views).ToListAsync());
        group.MapGet("/{id:guid}", async (Guid id, AppDbContext db) => { var item = await db.Articles.FindAsync(id); if (item is null) return Results.NotFound(); item.Views++; await db.SaveChangesAsync(); return Results.Ok(item); });
        group.MapPost("/", async (CreateArticleRequest r, AppDbContext db, ClaimsPrincipal user) => { var item = new KnowledgeArticle { Title = r.Title, Summary = r.Summary, Content = r.Content, Category = r.Category, Tags = r.Tags, Author = user.Identity?.Name ?? "Unknown" }; db.Add(item); await db.SaveChangesAsync(); return Results.Created($"/api/knowledge/{item.Id}", item); }).RequireAuthorization("Operator");
    }

    private static void MapAudit(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/audit", async (int? take, AppDbContext db) => await db.AuditEvents.OrderByDescending(x => x.CreatedAt).Take(Math.Clamp(take ?? 100, 1, 500)).ToListAsync()).RequireAuthorization("AdminOnly").WithTags("Audit");
        app.MapGet("/api/users", async (AppDbContext db) => await db.Users.Where(x => x.IsActive).Select(x => new { x.Id, x.DisplayName, x.Email, x.Role }).ToListAsync()).RequireAuthorization().WithTags("Users");
    }
}
