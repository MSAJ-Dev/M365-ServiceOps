using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ServiceOps.Api.Data;
using ServiceOps.Api.Domain;

namespace ServiceOps.Api.Services;

public interface ITokenService { string Create(AppUser user); }
public sealed class TokenService(IConfiguration configuration) : ITokenService
{
    public string Create(AppUser user)
    {
        var claims = new[] { new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()), new Claim(ClaimTypes.Name, user.DisplayName), new Claim(ClaimTypes.Email, user.Email), new Claim(ClaimTypes.Role, user.Role) };
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]!));
        var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddHours(8), signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}

public interface ISlaService
{
    (DateTimeOffset response, DateTimeOffset resolution) Calculate(TicketPriority priority, DateTimeOffset createdAt);
    Task<int> EscalateBreachesAsync(CancellationToken cancellationToken);
}

public sealed class SlaService(AppDbContext db) : ISlaService
{
    public (DateTimeOffset response, DateTimeOffset resolution) Calculate(TicketPriority priority, DateTimeOffset createdAt)
    {
        var hours = priority switch { TicketPriority.P1 => (0.25, 4), TicketPriority.P2 => (1, 8), TicketPriority.P3 => (4, 24), _ => (8, 72) };
        return (createdAt.AddHours(hours.Item1), createdAt.AddHours(hours.Item2));
    }

    public async Task<int> EscalateBreachesAsync(CancellationToken cancellationToken)
    {
        var now = DateTimeOffset.UtcNow;
        var breached = await db.Tickets.Where(x => !x.Escalated && x.ResolvedAt == null && x.ResolutionDueAt < now).ToListAsync(cancellationToken);
        foreach (var ticket in breached) ticket.Escalated = true;
        await db.SaveChangesAsync(cancellationToken);
        return breached.Count;
    }
}

public sealed class SlaEscalationWorker(IServiceScopeFactory scopeFactory, ILogger<SlaEscalationWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            using var scope = scopeFactory.CreateScope();
            var count = await scope.ServiceProvider.GetRequiredService<ISlaService>().EscalateBreachesAsync(stoppingToken);
            if (count > 0) logger.LogWarning("Escalated {Count} breached tickets", count);
            await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        }
    }
}

public interface IAuditService { Task RecordAsync(ClaimsPrincipal user, string action, string entityType, object entityId, string details, string ip); }
public sealed class AuditService(AppDbContext db) : IAuditService
{
    public async Task RecordAsync(ClaimsPrincipal user, string action, string entityType, object entityId, string details, string ip)
    {
        db.AuditEvents.Add(new AuditEvent { Actor = user.Identity?.Name ?? "system", Action = action, EntityType = entityType, EntityId = entityId.ToString()!, Details = details, IpAddress = ip });
        await db.SaveChangesAsync();
    }
}

public interface IIncidentAnalyticsService { Task<object> DetectRecurringAsync(); }
public sealed class IncidentAnalyticsService(AppDbContext db) : IIncidentAnalyticsService
{
    public async Task<object> DetectRecurringAsync()
    {
        var since = DateTimeOffset.UtcNow.AddDays(-30);
        var recent = await db.Tickets.Where(x => x.CreatedAt >= since)
            .Select(x => new { x.Fingerprint, x.Category, x.CreatedAt, x.Number }).ToListAsync();
        var clusters = recent
            .GroupBy(x => new { x.Fingerprint, x.Category })
            .Select(g => new { g.Key.Fingerprint, g.Key.Category, Count = g.Count(), Latest = g.Max(x => x.CreatedAt), TicketNumbers = g.Select(x => x.Number).ToArray() })
            .Where(x => x.Count >= 2).OrderByDescending(x => x.Count).ToList();
        return clusters;
    }

    public static string Fingerprint(string text)
    {
        var normalized = Regex.Replace(text.ToLowerInvariant(), @"[^a-z0-9 ]", " ");
        var stop = new HashSet<string> { "the", "a", "an", "to", "and", "is", "in", "for", "of", "my", "not" };
        return string.Join('-', normalized.Split(' ', StringSplitOptions.RemoveEmptyEntries).Where(x => !stop.Contains(x)).Distinct().Order().Take(8));
    }
}

public interface IGraphSimulationService { Task<object?> ExecuteAsync(Guid userId, string operation, string? value); }
public sealed class GraphSimulationService(AppDbContext db) : IGraphSimulationService
{
    public async Task<object?> ExecuteAsync(Guid userId, string operation, string? value)
    {
        var user = await db.DirectoryUsers.FindAsync(userId) ?? throw new KeyNotFoundException("Directory user not found");
        switch (operation.ToLowerInvariant())
        {
            case "reset-password": user.PasswordResetRequired = true; break;
            case "enable": user.AccountEnabled = true; break;
            case "disable": user.AccountEnabled = false; break;
            case "add-group": if (!string.IsNullOrWhiteSpace(value) && !user.Groups.Contains(value)) user.Groups = [.. user.Groups, value]; break;
            case "remove-group": if (!string.IsNullOrWhiteSpace(value)) user.Groups = user.Groups.Where(x => x != value).ToList(); break;
            case "assign-licence": if (!string.IsNullOrWhiteSpace(value) && !user.Licences.Contains(value)) user.Licences = [.. user.Licences, value]; break;
            case "remove-licence": if (!string.IsNullOrWhiteSpace(value)) user.Licences = user.Licences.Where(x => x != value).ToList(); break;
            default: throw new ArgumentException("Unsupported simulated Graph operation");
        }
        await db.SaveChangesAsync();
        return new { user.Id, user.UserPrincipalName, user.AccountEnabled, user.PasswordResetRequired, user.Groups, user.Licences, Simulation = true };
    }
}

public static class ChangeConflictDetector
{
    public static bool Overlaps(DateTimeOffset firstStart, DateTimeOffset firstEnd, DateTimeOffset secondStart, DateTimeOffset secondEnd) => firstStart < secondEnd && secondStart < firstEnd;
}
