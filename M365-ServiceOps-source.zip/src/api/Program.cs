using System.Text;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ServiceOps.Api.Data;
using ServiceOps.Api.Endpoints;
using ServiceOps.Api.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(options => options.UseNpgsql(builder.Configuration.GetConnectionString("Default")));
builder.Services.ConfigureHttpJsonOptions(options => options.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddScoped<ITokenService, TokenService>();
builder.Services.AddScoped<ISlaService, SlaService>();
builder.Services.AddScoped<IAuditService, AuditService>();
builder.Services.AddScoped<IIncidentAnalyticsService, IncidentAnalyticsService>();
builder.Services.AddScoped<IGraphSimulationService, GraphSimulationService>();
builder.Services.AddHostedService<SlaEscalationWorker>();

var jwtKey = builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("Jwt:Key is required");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters { ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true, ValidIssuer = builder.Configuration["Jwt:Issuer"], ValidAudience = builder.Configuration["Jwt:Audience"], IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)), ClockSkew = TimeSpan.FromMinutes(1) };
});
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("Operator", p => p.RequireRole("Admin", "Analyst", "ChangeManager"));
    options.AddPolicy("ChangeOperator", p => p.RequireRole("Admin", "ChangeManager"));
    options.AddPolicy("ChangeManager", p => p.RequireRole("Admin", "ChangeManager"));
    options.AddPolicy("AdminOnly", p => p.RequireRole("Admin"));
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options => { options.SwaggerDoc("v1", new OpenApiInfo { Title = "M365 ServiceOps API", Version = "v1", Description = "ITSM, major incident, change, directory simulation, monitoring, and knowledge APIs." }); options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme { Name = "Authorization", Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT", In = ParameterLocation.Header }); options.AddSecurityRequirement(new OpenApiSecurityRequirement { [new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }] = Array.Empty<string>() }); });
builder.Services.AddHealthChecks().AddDbContextCheck<AppDbContext>();
builder.Services.AddCors(options => options.AddDefaultPolicy(p => p.WithOrigins("http://localhost:3000", "http://localhost:5173").AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
app.UseExceptionHandler(handler => handler.Run(async context =>
{
    var error = context.Features.Get<IExceptionHandlerFeature>()?.Error;
    context.Response.StatusCode = error is KeyNotFoundException ? 404 : error is ArgumentException ? 400 : 500;
    await context.Response.WriteAsJsonAsync(new { error = error?.Message ?? "Unexpected server error", traceId = context.TraceIdentifier });
}));
app.UseSwagger(); app.UseSwaggerUI();
app.UseCors(); app.UseAuthentication(); app.UseAuthorization();
app.MapHealthChecks("/health"); app.MapServiceOpsApi();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var sla = scope.ServiceProvider.GetRequiredService<ISlaService>();
    await SeedData.InitializeAsync(db, sla);
}

app.Run();

public partial class Program;
