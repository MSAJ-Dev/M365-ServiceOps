using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using ServiceOps.Api.Domain;

namespace ServiceOps.Api.Data;

public sealed class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketComment> TicketComments => Set<TicketComment>();
    public DbSet<MajorIncident> MajorIncidents => Set<MajorIncident>();
    public DbSet<IncidentUpdate> IncidentUpdates => Set<IncidentUpdate>();
    public DbSet<ChangeRequest> Changes => Set<ChangeRequest>();
    public DbSet<ChangeApproval> ChangeApprovals => Set<ChangeApproval>();
    public DbSet<CabMeeting> CabMeetings => Set<CabMeeting>();
    public DbSet<DirectoryUser> DirectoryUsers => Set<DirectoryUser>();
    public DbSet<MonitoredResource> Resources => Set<MonitoredResource>();
    public DbSet<MonitoringAlert> Alerts => Set<MonitoringAlert>();
    public DbSet<KnowledgeArticle> Articles => Set<KnowledgeArticle>();
    public DbSet<AuditEvent> AuditEvents => Set<AuditEvent>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        var strings = new ValueConverter<List<string>, string>(
            value => JsonSerializer.Serialize(value, (JsonSerializerOptions?)null),
            value => JsonSerializer.Deserialize<List<string>>(value, (JsonSerializerOptions?)null) ?? new());

        modelBuilder.Entity<AppUser>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<Ticket>().HasIndex(x => x.Number).IsUnique();
        modelBuilder.Entity<Ticket>().HasIndex(x => new { x.Status, x.Priority });
        modelBuilder.Entity<MajorIncident>().HasIndex(x => x.Number).IsUnique();
        modelBuilder.Entity<ChangeRequest>().HasIndex(x => x.Number).IsUnique();
        modelBuilder.Entity<DirectoryUser>().HasIndex(x => x.UserPrincipalName).IsUnique();
        modelBuilder.Entity<DirectoryUser>().Property(x => x.Groups).HasConversion(strings);
        modelBuilder.Entity<DirectoryUser>().Property(x => x.Licences).HasConversion(strings);
        modelBuilder.Entity<AuditEvent>().HasIndex(x => x.CreatedAt);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        foreach (var entry in ChangeTracker.Entries<Entity>().Where(x => x.State == EntityState.Modified))
            entry.Entity.UpdatedAt = DateTimeOffset.UtcNow;
        return await base.SaveChangesAsync(cancellationToken);
    }
}
