using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using ServiceOps.Api.Domain;
using ServiceOps.Api.Services;

namespace ServiceOps.Api.Data;

public static class SeedData
{
    public static async Task InitializeAsync(AppDbContext db, ISlaService sla)
    {
        await db.Database.EnsureCreatedAsync();
        if (await db.Users.AnyAsync()) return;

        var hasher = new PasswordHasher<AppUser>();
        AppUser User(string name, string email, string role)
        {
            var user = new AppUser { DisplayName = name, Email = email, Role = role, PasswordHash = "" };
            user.PasswordHash = hasher.HashPassword(user, "Demo123!");
            return user;
        }
        var admin = User("Avery Administrator", "admin@contoso.demo", "Admin");
        var analyst = User("Alex Analyst", "analyst@contoso.demo", "Analyst");
        var change = User("Casey Change Manager", "change@contoso.demo", "ChangeManager");
        var viewer = User("Val Viewer", "viewer@contoso.demo", "Viewer");
        db.Users.AddRange(admin, analyst, change, viewer);

        Ticket TicketOf(string number, string title, string category, TicketPriority priority, TicketStatus status, int ageHours)
        {
            var created = DateTimeOffset.UtcNow.AddHours(-ageHours);
            var deadlines = sla.Calculate(priority, created);
            return new Ticket { Number = number, Title = title, Description = title + " reported by a corporate user.", Category = category, Priority = priority, Status = status, RequesterEmail = "employee@contoso.demo", Assignee = analyst, CreatedAt = created, ResponseDueAt = deadlines.response, ResolutionDueAt = deadlines.resolution, FirstRespondedAt = status == TicketStatus.New ? null : created.AddMinutes(20), ResolvedAt = status == TicketStatus.Resolved ? created.AddHours(6) : null, Fingerprint = IncidentAnalyticsService.Fingerprint(title) };
        }
        db.Tickets.AddRange(
            TicketOf("INC-1001", "Teams calls dropping in Vancouver office", "Microsoft Teams", TicketPriority.P1, TicketStatus.InProgress, 2),
            TicketOf("INC-1002", "Teams calls dropping in Vancouver office", "Microsoft Teams", TicketPriority.P2, TicketStatus.Assigned, 28),
            TicketOf("INC-1003", "Teams call drops from Vancouver", "Microsoft Teams", TicketPriority.P3, TicketStatus.Resolved, 72),
            TicketOf("REQ-1004", "Microsoft 365 E3 licence required", "Access Request", TicketPriority.P3, TicketStatus.Assigned, 5),
            TicketOf("INC-1005", "SharePoint finance site access denied", "SharePoint", TicketPriority.P2, TicketStatus.InProgress, 3),
            TicketOf("INC-1006", "Outlook desktop repeatedly requests password", "Exchange Online", TicketPriority.P3, TicketStatus.New, 1));

        var incident = new MajorIncident { Number = "MI-2026-008", Title = "Teams voice degradation — Western Canada", Service = "Microsoft Teams", Severity = "SEV-1", Status = "Identified", Commander = "Avery Administrator", BusinessImpact = "Approximately 240 users experience intermittent call drops.", StartedAt = DateTimeOffset.UtcNow.AddMinutes(-78) };
        incident.Updates.AddRange([
            new IncidentUpdate { Status = "Investigating", Message = "Service desk confirmed correlated call-quality reports.", Author = "Alex Analyst", CreatedAt = DateTimeOffset.UtcNow.AddMinutes(-76) },
            new IncidentUpdate { Status = "Identified", Message = "Traffic isolated to the Vancouver SBC route; vendor engaged.", Author = "Avery Administrator", CreatedAt = DateTimeOffset.UtcNow.AddMinutes(-31) }
        ]);
        db.MajorIncidents.Add(incident);

        db.Changes.AddRange(
            new ChangeRequest { Number = "CHG-2001", Title = "Upgrade SharePoint Framework web parts", Type = "Normal", Risk = "Medium", Impact = "Brief site component restart", ImplementationPlan = "Deploy package to app catalog and enable tenant-wide.", TestPlan = "Validate five critical sites and accessibility checks.", RollbackPlan = "Restore prior package version from app catalog.", Owner = "Casey Change Manager", Status = ChangeStatus.Submitted, PlannedStart = DateTimeOffset.UtcNow.AddDays(2).Date.AddHours(18), PlannedEnd = DateTimeOffset.UtcNow.AddDays(2).Date.AddHours(20) },
            new ChangeRequest { Number = "CHG-2002", Title = "Rotate Entra application secret", Type = "Standard", Risk = "Low", Impact = "No expected user impact", ImplementationPlan = "Add new secret, update vault, validate, remove old secret.", TestPlan = "Run authentication smoke test.", RollbackPlan = "Restore old secret before its expiration.", Owner = "Avery Administrator", Status = ChangeStatus.Approved, PlannedStart = DateTimeOffset.UtcNow.AddDays(4).Date.AddHours(17), PlannedEnd = DateTimeOffset.UtcNow.AddDays(4).Date.AddHours(18) });

        db.DirectoryUsers.AddRange(
            new DirectoryUser { DisplayName = "Jordan Lee", UserPrincipalName = "jordan.lee@contoso.demo", Groups = ["All Employees", "Finance-SP"], Licences = ["Microsoft 365 E3", "Power BI Pro"] },
            new DirectoryUser { DisplayName = "Morgan Chen", UserPrincipalName = "morgan.chen@contoso.demo", Groups = ["All Employees"], Licences = ["Microsoft 365 E3"] },
            new DirectoryUser { DisplayName = "Taylor Singh", UserPrincipalName = "taylor.singh@contoso.demo", Groups = ["All Employees", "IT Service Desk"], Licences = ["Microsoft 365 E5"] });

        var resources = new[] {
            new MonitoredResource { Name = "dc-vm-01", ResourceType = "Azure VM", Environment = "Production", Status = MonitorStatus.Healthy, CpuPercent = 34, MemoryPercent = 61, LatencyMs = 18 },
            new MonitoredResource { Name = "sp-intranet", ResourceType = "Application", Environment = "Production", Status = MonitorStatus.Warning, CpuPercent = 72, MemoryPercent = 79, LatencyMs = 940 },
            new MonitoredResource { Name = "van-edge-01", ResourceType = "Network", Environment = "Production", Status = MonitorStatus.Critical, CpuPercent = 91, MemoryPercent = 88, LatencyMs = 1340 },
            new MonitoredResource { Name = "intune-enrolment", ResourceType = "Endpoint Service", Environment = "Production", Status = MonitorStatus.Healthy, CpuPercent = 22, MemoryPercent = 45, LatencyMs = 210 }
        };
        db.Resources.AddRange(resources);
        db.Alerts.AddRange(
            new MonitoringAlert { ResourceId = resources[1].Id, Severity = "Warning", Message = "SharePoint intranet latency above 800 ms." },
            new MonitoringAlert { ResourceId = resources[2].Id, Severity = "Critical", Message = "WAN packet loss above 8%; Teams media affected." });

        db.Articles.AddRange(
            new KnowledgeArticle { Title = "Reset a Microsoft 365 password safely", Summary = "Identity-verification and reset procedure for service desk analysts.", Category = "Entra ID", Tags = "password,entra,tier1", Author = "Alex Analyst", Content = "1. Verify identity using two approved factors.\n2. Check risky sign-ins and account state.\n3. Trigger a temporary password reset.\n4. Require change at next sign-in.\n5. Record the ticket and audit evidence." },
            new KnowledgeArticle { Title = "Troubleshoot Microsoft Teams call quality", Summary = "Tier 1/2 workflow for latency, jitter, packet loss, and client issues.", Category = "Microsoft Teams", Tags = "teams,voice,network,tier2", Author = "Avery Administrator", Content = "Capture scope, time, location and affected users. Review network telemetry. Run the Teams client health checks. Correlate recent changes. Escalate as a major incident when impact thresholds are met." },
            new KnowledgeArticle { Title = "Restore SharePoint site access", Summary = "Diagnose Entra group and SharePoint permission inheritance.", Category = "SharePoint", Tags = "sharepoint,permissions,access", Author = "Alex Analyst", Content = "Confirm the business owner approved access. Check group membership and inheritance. Use least privilege. Allow directory propagation time. Validate with the requester and document the change." });

        db.CabMeetings.Add(new CabMeeting { Title = "Weekly Change Advisory Board", ScheduledAt = DateTimeOffset.UtcNow.AddDays(1).Date.AddHours(10), Chair = "Casey Change Manager", Attendees = "Operations, Security, Applications, Service Desk", Agenda = "Review submitted and high-risk changes; identify scheduling conflicts." });
        await db.SaveChangesAsync();
    }
}
