namespace ServiceOps.Api.Domain;

public enum TicketPriority { P1, P2, P3, P4 }
public enum TicketStatus { New, Assigned, InProgress, Pending, Resolved, Closed }
public enum ChangeStatus { Draft, Submitted, Approved, Rejected, Scheduled, Implemented, RolledBack }
public enum ApprovalDecision { Pending, Approved, Rejected }
public enum MonitorStatus { Healthy, Warning, Critical, Unknown }

public abstract class Entity
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class AppUser : Entity
{
    public required string DisplayName { get; set; }
    public required string Email { get; set; }
    public required string PasswordHash { get; set; }
    public required string Role { get; set; }
    public bool IsActive { get; set; } = true;
}

public sealed class Ticket : Entity
{
    public required string Number { get; set; }
    public required string Title { get; set; }
    public required string Description { get; set; }
    public required string Category { get; set; }
    public TicketPriority Priority { get; set; }
    public TicketStatus Status { get; set; }
    public string RequesterEmail { get; set; } = "";
    public Guid? AssigneeId { get; set; }
    public AppUser? Assignee { get; set; }
    public DateTimeOffset ResponseDueAt { get; set; }
    public DateTimeOffset ResolutionDueAt { get; set; }
    public DateTimeOffset? FirstRespondedAt { get; set; }
    public DateTimeOffset? ResolvedAt { get; set; }
    public bool Escalated { get; set; }
    public string? Resolution { get; set; }
    public string Fingerprint { get; set; } = "";
    public List<TicketComment> Comments { get; set; } = [];
}

public sealed class TicketComment : Entity
{
    public Guid TicketId { get; set; }
    public required string Author { get; set; }
    public required string Body { get; set; }
    public bool IsInternal { get; set; }
}

public sealed class MajorIncident : Entity
{
    public required string Number { get; set; }
    public required string Title { get; set; }
    public required string Service { get; set; }
    public string Severity { get; set; } = "SEV-1";
    public string Status { get; set; } = "Investigating";
    public string Commander { get; set; } = "Unassigned";
    public string BusinessImpact { get; set; } = "";
    public DateTimeOffset StartedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? ResolvedAt { get; set; }
    public List<IncidentUpdate> Updates { get; set; } = [];
}

public sealed class IncidentUpdate : Entity
{
    public Guid MajorIncidentId { get; set; }
    public required string Status { get; set; }
    public required string Message { get; set; }
    public required string Author { get; set; }
    public bool CustomerVisible { get; set; } = true;
}

public sealed class ChangeRequest : Entity
{
    public required string Number { get; set; }
    public required string Title { get; set; }
    public string Type { get; set; } = "Normal";
    public string Risk { get; set; } = "Medium";
    public string Impact { get; set; } = "";
    public string ImplementationPlan { get; set; } = "";
    public string TestPlan { get; set; } = "";
    public string RollbackPlan { get; set; } = "";
    public ChangeStatus Status { get; set; } = ChangeStatus.Draft;
    public string Owner { get; set; } = "";
    public DateTimeOffset PlannedStart { get; set; }
    public DateTimeOffset PlannedEnd { get; set; }
    public List<ChangeApproval> Approvals { get; set; } = [];
}

public sealed class ChangeApproval : Entity
{
    public Guid ChangeRequestId { get; set; }
    public required string Approver { get; set; }
    public ApprovalDecision Decision { get; set; }
    public string? Comment { get; set; }
    public DateTimeOffset? DecidedAt { get; set; }
}

public sealed class CabMeeting : Entity
{
    public required string Title { get; set; }
    public DateTimeOffset ScheduledAt { get; set; }
    public string Chair { get; set; } = "";
    public string Attendees { get; set; } = "";
    public string Agenda { get; set; } = "";
    public string Minutes { get; set; } = "";
}

public sealed class DirectoryUser : Entity
{
    public required string UserPrincipalName { get; set; }
    public required string DisplayName { get; set; }
    public bool AccountEnabled { get; set; } = true;
    public bool PasswordResetRequired { get; set; }
    public List<string> Groups { get; set; } = [];
    public List<string> Licences { get; set; } = [];
}

public sealed class MonitoredResource : Entity
{
    public required string Name { get; set; }
    public required string ResourceType { get; set; }
    public required string Environment { get; set; }
    public MonitorStatus Status { get; set; }
    public double CpuPercent { get; set; }
    public double MemoryPercent { get; set; }
    public double LatencyMs { get; set; }
    public DateTimeOffset LastCheckedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class MonitoringAlert : Entity
{
    public Guid ResourceId { get; set; }
    public required string Severity { get; set; }
    public required string Message { get; set; }
    public bool Acknowledged { get; set; }
    public DateTimeOffset DetectedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class KnowledgeArticle : Entity
{
    public required string Title { get; set; }
    public required string Summary { get; set; }
    public required string Content { get; set; }
    public required string Category { get; set; }
    public string Tags { get; set; } = "";
    public string Author { get; set; } = "";
    public bool Published { get; set; } = true;
    public int Views { get; set; }
}

public sealed class AuditEvent : Entity
{
    public required string Actor { get; set; }
    public required string Action { get; set; }
    public required string EntityType { get; set; }
    public required string EntityId { get; set; }
    public string Details { get; set; } = "";
    public string IpAddress { get; set; } = "";
}
