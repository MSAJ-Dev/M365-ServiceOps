using ServiceOps.Api.Domain;

namespace ServiceOps.Api.Contracts;

public record LoginRequest(string Email, string Password);
public record CreateTicketRequest(string Title, string Description, string Category, TicketPriority Priority, string RequesterEmail);
public record UpdateTicketRequest(TicketStatus Status, Guid? AssigneeId, string? Resolution);
public record AddCommentRequest(string Body, bool IsInternal);
public record CreateIncidentRequest(string Title, string Service, string Severity, string BusinessImpact, string Commander);
public record AddIncidentUpdateRequest(string Status, string Message, bool CustomerVisible);
public record CreateChangeRequest(string Title, string Type, string Risk, string Impact, string ImplementationPlan, string TestPlan, string RollbackPlan, string Owner, DateTimeOffset PlannedStart, DateTimeOffset PlannedEnd);
public record DecideChangeRequest(ApprovalDecision Decision, string Comment);
public record DirectoryOperationRequest(string Operation, string? Value);
public record CreateArticleRequest(string Title, string Summary, string Content, string Category, string Tags);
