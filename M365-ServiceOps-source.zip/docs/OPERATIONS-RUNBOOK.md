# Operations runbook

## Health and startup

Run `docker compose ps`; all three services should be running and PostgreSQL should be healthy. Request `http://localhost:8080/health`; `Healthy` confirms API-to-database readiness. The web root should load and authentication should succeed with a documented demo user.

## Common failures

| Symptom | Check | Recovery |
|---|---|---|
| Web loads but login fails | `docker compose logs api` and `/health` | Confirm PostgreSQL is healthy and `.env` values match; restart `api`. |
| API cannot connect to database | `docker compose logs postgres` | Confirm connection variables and free disk; do not expose port 5432 unnecessarily. |
| UI returns 502 | `docker compose ps api` | Wait for API start or rebuild `docker compose up --build api web`. |
| Local Vite API request fails | API listening on 8080 | Start .NET first; Vite proxy points to `http://localhost:8080`. |
| Demo records unexpectedly reset | Database volume removed | The seed is recreated only after a new database is created. |
| PowerShell receives 401 | Token older than eight hours | Run `Connect-ServiceOps.ps1` again. |

## Incident operating model

For a P1: acknowledge within 15 minutes; assign an incident commander; define affected service, scope and business impact; open a major incident; establish a timeline; communicate every 30 minutes; preserve technical evidence; document resolution; schedule a post-incident review; create problem/change/knowledge records as needed.

For a P2: acknowledge within one hour, resolve within eight hours, and elevate when impact expands, a critical service is involved, or correlated reports show recurrence.

## Backup and restore

For a real deployment, schedule encrypted PostgreSQL logical and physical backups, test point-in-time recovery, keep restoration credentials separately, and document RPO/RTO. The demo uses a named Docker volume. `docker compose down` preserves it. `docker compose down -v` deletes it and should only be used when intentionally resetting demo data.

## Change procedure

Require business impact, risk, implementation, validation, and rollback plans. Search conflicts before CAB. Confirm responsible owner and implementation window. Reject incomplete or conflicting work. During implementation, record start, validation evidence, outcome, and rollback reason. For emergency change, require retrospective CAB review.

## Monitoring thresholds in the demo

- Critical: CPU above 90% or latency above 1200 ms.
- Warning: CPU above 75% or latency above 800 ms.
- Healthy: neither warning threshold is exceeded.

Production thresholds must be service-specific, baseline-informed, sustained over time, and paired with runbooks to avoid alert fatigue.
