# M365 ServiceOps Command Center — Complete Project Guide

## 1. What this project demonstrates

M365 ServiceOps is a working full-stack portfolio project for Tier 1/2 service delivery, Microsoft 365 support, incident and request management, major-incident leadership, change governance, monitoring, documentation, and operational reporting. It is intentionally safe: Microsoft Graph behaviour is simulated inside PostgreSQL, so a recruiter can execute password, group, licence, and account operations without access to a real tenant.

The application demonstrates the complete lifecycle:

1. A user submits an incident or request.
2. Priority determines response and resolution SLA deadlines.
3. An analyst assigns, works, comments on, resolves, and documents the ticket.
4. A background worker flags overdue unresolved tickets.
5. Similar 30-day ticket fingerprints reveal recurring problems for root-cause analysis.
6. High-impact failures become major incidents with a commander, business impact, timeline, and communications.
7. Planned work becomes a change request with risk, impact, test, implementation, and rollback plans.
8. CAB reviewers detect conflicting windows and approve or reject changes.
9. Administrators simulate Entra ID and Microsoft 365 support operations.
10. Infrastructure telemetry and alerts connect technical symptoms to service impact.
11. Knowledge articles convert successful resolutions into reusable training.
12. RBAC and audit history preserve accountability.

## 2. Technology choices and why they fit

| Technology | Responsibility | Why it belongs here |
|---|---|---|
| C# / .NET 8 | API, rules, authentication, background SLA processing | Common in Microsoft enterprise environments; strongly typed and well suited to service applications. |
| ASP.NET Core Minimal APIs | HTTP endpoints and policy enforcement | Keeps routes explicit and compact while retaining middleware, OpenAPI, DI, health checks, and authorization. |
| Entity Framework Core | Object-relational mapping and persistence | Tracks operational entities, relationships, indexes, and timestamps with PostgreSQL support. |
| PostgreSQL 16 | Durable service records | Reliable relational storage for tickets, approvals, incidents, users, telemetry, knowledge, and audit data. |
| React 19 + TypeScript | Responsive service operations console | Component-driven UI with compile-time types and effective dashboard interactions. |
| Recharts | Service-demand chart | Converts ticket categories into an accessible operational visualization. |
| PowerShell | Support automation clients | Directly aligns with Microsoft 365/Entra service-desk workflows and demonstrates safe API automation. |
| JWT + RBAC | Authentication and authorization | Demonstrates separation of viewer, analyst, change, and administrator duties. |
| Docker Compose | Repeatable runtime | Starts PostgreSQL, API, and web gateway with one command and no host-specific configuration. |
| Nginx | Static UI hosting and API reverse proxy | Serves the production React bundle and keeps browser requests on one origin. |
| Swagger/OpenAPI | Interactive API contract | Makes endpoints testable and documents payloads for integration work. |
| xUnit | Backend rule tests | Verifies the highest-risk logic: SLA targets, escalation, recurring fingerprints, and change conflicts. |
| GitHub Actions | Continuous integration | Rebuilds and tests the API and production web bundle on every push or pull request. |

## 3. Architecture

```mermaid
flowchart TD
  B["Browser / React console"] -->|HTTPS / JSON + JWT| N["Nginx gateway"]
  P["PowerShell automation"] -->|REST + JWT| A["ASP.NET Core API"]
  N --> A
  A --> R["RBAC policies"]
  A --> S["Domain services"]
  S --> E["EF Core"]
  E --> D[(PostgreSQL)]
  W["SLA background worker"] --> S
  A --> O["Swagger + health checks"]
```

The browser signs in through `/api/auth/login`. The API validates credentials and returns an eight-hour JWT containing the user identifier, display name, email, and role. The browser adds it to subsequent requests. Endpoint policies authorize the action before a service or database operation runs. Mutations create an audit record where accountability matters.

## 4. Source tree and file connections

```text
m365-service-ops/
├── README.md                         entry point and quick start
├── docker-compose.yml                joins PostgreSQL, API, and web containers
├── .env.example                      runtime variable template
├── .github/workflows/ci.yml          CI build and test pipeline
├── docs/
│   ├── COMPLETE-PROJECT-GUIDE.md     this architecture/function/file review
│   ├── API.md                        route and payload reference
│   ├── SECURITY.md                   controls and production hardening
│   └── OPERATIONS-RUNBOOK.md         support and recovery procedures
├── scripts/
│   ├── Connect-ServiceOps.ps1        obtains a JWT session
│   ├── New-ServiceOpsTicket.ps1      submits tickets using that session
│   ├── Invoke-M365SupportOperation.ps1 simulates Graph operations
│   └── Get-ServiceHealth.ps1         summarizes resource/alert health
├── src/api/
│   ├── Program.cs                    application composition and middleware
│   ├── Domain/Entities.cs            domain types and enums
│   ├── Contracts/Requests.cs         input DTO contracts
│   ├── Data/AppDbContext.cs          EF model and persistence behaviour
│   ├── Data/SeedData.cs              repeatable demonstration dataset
│   ├── Services/CoreServices.cs      token, SLA, audit, analysis, Graph logic
│   └── Endpoints/ApiEndpoints.cs     HTTP routes and role gates
├── src/web/
│   ├── src/api.ts                    authenticated HTTP client and formatting
│   ├── src/types.ts                  API response types
│   ├── src/App.tsx                   screens and interaction components
│   ├── src/styles.css                visual system and responsive layout
│   ├── vite.config.ts                development server and API proxy
│   ├── Dockerfile                    production web build
│   └── nginx.conf                    SPA fallback and `/api` proxy
└── tests/ServiceOps.Tests/           domain and service rule tests
```

### Connection sequence

`docker-compose.yml` supplies the connection string and JWT key to the API. `Program.cs` registers `AppDbContext` and services, then maps `ApiEndpoints`. An endpoint accepts a type from `Contracts/Requests.cs`, uses a service from `CoreServices.cs`, and persists a domain entity from `Entities.cs` through `AppDbContext`. `SeedData` creates the initial database the first time the API starts. React's `api.ts` calls an endpoint; `types.ts` describes the response and `App.tsx` renders it. Nginx serves React and forwards `/api` to the API container. PowerShell scripts are a second client of the same API.

## 5. Backend function-by-function review

### `Program.cs`

- Top-level application code constructs `WebApplicationBuilder`, registers dependencies and starts the host. Central composition prevents infrastructure details from leaking into domain code.
- `AddDbContext` registers one scoped `AppDbContext` per request and configures PostgreSQL through the `Default` connection string.
- `ConfigureHttpJsonOptions` serializes enums such as `P1` and `Approved` as readable strings instead of integers.
- Service registrations map each interface to its implementation; consumers depend on abstractions.
- `AddHostedService<SlaEscalationWorker>` runs deadline evaluation independently of browser requests.
- `AddAuthentication(...).AddJwtBearer(...)` validates issuer, audience, expiration and HMAC signature.
- Authorization policies encode the permissions used by endpoints: `Operator`, `ChangeOperator`, `ChangeManager`, and `AdminOnly`.
- Swagger registration publishes the API contract and defines the Bearer authorization control.
- `AddHealthChecks().AddDbContextCheck` makes `/health` fail when storage is unavailable, which is useful for orchestration.
- CORS permits only the two local development origins.
- `UseExceptionHandler` converts expected missing-record and invalid-operation exceptions into 404/400 responses and adds a trace ID.
- Middleware order is important: errors wrap the pipeline; CORS executes before authentication; authentication establishes identity before authorization.
- The seed scope obtains the same registered database and SLA service used by requests. `InitializeAsync` creates and seeds storage only when no users exist.

### `Domain/Entities.cs`

- `TicketPriority`, `TicketStatus`, `ChangeStatus`, `ApprovalDecision`, and `MonitorStatus` constrain workflow values and prevent arbitrary state strings.
- `Entity` supplies UUID identity plus created/updated UTC timestamps to every record.
- `AppUser` contains login identity, versioned password hash, role, and active flag.
- `Ticket` holds classification, requester, assignment, SLA deadlines, response/resolution timestamps, escalation, searchable fingerprint, comments, and outcome.
- `TicketComment` separates internal work notes from customer-visible discussion.
- `MajorIncident` owns the command record: severity, affected service, commander, impact, start/resolution, and timeline updates.
- `IncidentUpdate` records chronological status communication and whether it is customer visible.
- `ChangeRequest` requires operational plans and a scheduled window; `ChangeApproval` preserves each review decision.
- `CabMeeting` stores governance schedule, participation, agenda, and minutes.
- `DirectoryUser` is a tenant-safe Entra model. Groups and licences are persisted as JSON arrays.
- `MonitoredResource` represents a VM, network, application, or endpoint service with CPU, memory, latency, and health.
- `MonitoringAlert` is a durable detection with acknowledgement state.
- `KnowledgeArticle` contains searchable support instructions and simple usage analytics.
- `AuditEvent` is the actor/action/target/details/source record for accountability.

### `Contracts/Requests.cs`

Each immutable record is a request boundary. `LoginRequest` accepts credentials. `CreateTicketRequest` and `UpdateTicketRequest` separate ticket creation from workflow changes. `AddCommentRequest` carries visibility. `CreateIncidentRequest` and `AddIncidentUpdateRequest` model declaration and communication. `CreateChangeRequest` requires implementation, test, rollback, owner, and window data. `DecideChangeRequest` records approval plus rationale. `DirectoryOperationRequest` carries an allow-listed operation and optional group/licence value. `CreateArticleRequest` prevents clients from setting server-managed identity, timestamps, author, or views.

### `Data/AppDbContext.cs`

- The primary constructor receives EF options from dependency injection.
- Each `DbSet` exposes a collection for one aggregate or related record.
- `OnModelCreating` adds unique indexes for login, ticket, incident, change, and directory identifiers; a composite ticket queue index; and a chronological audit index.
- The `ValueConverter` serializes group/licence lists to PostgreSQL text JSON while preserving a simple demo schema.
- `SaveChangesAsync` automatically refreshes `UpdatedAt` for modified entities, preventing every endpoint from duplicating timestamp logic.

### `Data/SeedData.cs`

- `InitializeAsync` creates the schema and exits when users already exist, making container restarts idempotent.
- Local `User` constructs each demo identity and hashes `Demo123!` with `PasswordHasher<AppUser>`.
- Local `TicketOf` applies the real SLA calculator and fingerprint function to seed records instead of copying rule output.
- The seed set intentionally includes similar Teams tickets, a live major incident, multiple changes, directory identities, unhealthy resources, alerts, articles, and a CAB meeting so every screen demonstrates value immediately.

### `Services/CoreServices.cs`

- `ITokenService.Create` is implemented by `TokenService.Create`. It builds identity and role claims, signs an eight-hour HMAC-SHA256 token, and returns its compact serialized form.
- `ISlaService.Calculate` maps P1/P2/P3/P4 to response targets of 15 minutes/1 hour/4 hours/8 hours and resolution targets of 4/8/24/72 hours.
- `ISlaService.EscalateBreachesAsync` selects unresolved, unflagged tickets past resolution due time, marks them escalated, saves once, and returns the count.
- `SlaEscalationWorker.ExecuteAsync` creates a fresh dependency-injection scope every minute, invokes escalation, logs meaningful breach events, then waits with cancellation support.
- `IAuditService.RecordAsync` derives the authenticated actor, writes target and source details, and saves the event. It never trusts a client-supplied actor.
- `IIncidentAnalyticsService.DetectRecurringAsync` groups the last 30 days by normalized fingerprint and category, retains groups of two or more, and reports count/latest/ticket numbers.
- `IncidentAnalyticsService.Fingerprint` lowercases input, removes punctuation, drops common stop words, deduplicates and sorts key terms, and keeps eight. This is deterministic and explainable—not opaque AI.
- `IGraphSimulationService.ExecuteAsync` loads a local directory user and applies one operation from a strict switch: reset password, enable/disable, add/remove group, or assign/remove licence. Unsupported requests fail safely.
- `ChangeConflictDetector.Overlaps` implements the standard half-open interval rule. Back-to-back windows are allowed; true overlap is reported.

### `Endpoints/ApiEndpoints.cs`

- `MapServiceOpsApi` is the single route composition function and calls each bounded route mapper.
- `MapAuth` verifies an active user with the Identity password hasher and returns a safe user projection plus JWT.
- `MapDashboard` calculates open/P1/major-incident counts, SLA compliance, mean resolution time, breaches, critical resources, category demand, and recent queue items.
- `MapTickets` provides filtered list/detail, creation, update, comment, and recurring-analysis routes. Creation calculates deadlines and fingerprint server-side. Update stamps first response and resolution only when the workflow reaches those states.
- `MapMajorIncidents` lists full timelines, declares command records with generated numbers, appends updates, and closes duration when status becomes Resolved.
- `MapChanges` lists changes, uses the interval detector across unique pairs, validates that end follows start, submits planned work, applies CAB decisions, and exposes meeting details.
- `MapDirectory` searches simulated identities and routes allow-listed changes through the Graph service and audit service.
- `MapMonitoring` reads resources/alerts, acknowledges alerts, and produces bounded random telemetry for demonstration. Health is recalculated from CPU and latency thresholds.
- `MapKnowledge` performs case-insensitive title/summary/tag search, increments article views, and assigns article author from authenticated identity.
- `MapAudit` restricts audit history to administrators and exposes a password-free user assignment list to authenticated users.

## 6. Frontend function-by-function review

### `src/api.ts`

- `setToken` updates the in-memory token and browser storage together.
- `api<T>` adds JSON and Bearer headers, sends a typed request, centrally handles 401 logout, converts error bodies into `Error`, and returns parsed JSON.
- `formatAge` converts timestamps to compact operational ages (`18m`, `3h`, `2d`).
- `formatDate` renders a consistent Canadian date/time for incident and change records.

### `src/App.tsx`

- `App` restores the local user, responds to unauthorized events, owns navigation/mobile state, renders role-aware pages, and securely clears login state.
- `Login` uses controlled fields, submits credentials, stores the returned token/user, shows errors, and provides a ready demo identity.
- `useLoad<T>` is the shared query hook. Its memoized `load` function manages loading, error, data, and manual refresh without duplicating fetch state in every screen.
- `Badge` converts statuses into consistent semantic pills; `Empty` provides common loading and error feedback.
- `Dashboard` renders live KPI cards, service-demand bars, recent queue work, and direct navigation to operations.
- `Tickets` loads and locally searches the queue, displays priority/status/deadlines/assignment, and refreshes after creation.
- `TicketModal` controls the create form and relies on the API—not the browser—to calculate SLA deadlines and ticket numbers.
- `MajorIncidents` displays business impact, live ownership/duration, a reverse chronological timeline, and communication cadence.
- `Changes` displays risk, approval state, implementation window, owner, rollback readiness, and conflict warnings.
- `Cab` renders scheduled governance details plus an operational readiness checklist.
- `Directory` searches users and runs audited, disabled-while-busy Graph simulations before refreshing state.
- `Monitoring` displays infrastructure cards and starts a simulated telemetry poll; `Meter` renders bounded usage bars.
- `Knowledge` memoizes client-side search across title, summary, and tags and renders training-focused article cards.
- `Audit` enforces a second UI-level role guard while the API remains the authoritative security layer.

### Other web files

- `types.ts` defines the response shapes shared by screens.
- `main.tsx` mounts the application and global stylesheet once.
- `styles.css` defines the visual tokens, desktop shell, status semantics, tables, forms, incident timeline, telemetry cards, login experience, and responsive breakpoints.
- `vite.config.ts` enables React and proxies API/health requests to local .NET during development.
- `nginx.conf` uses an SPA fallback and forwards container traffic to `api:8080`.
- The web `Dockerfile` builds assets in Node and copies only output into a small Nginx runtime image.

## 7. Essential feature implementation map

| Requested capability | Implementation |
|---|---|
| Submission, category, priority, assignment | `Ticket`, ticket endpoints, ticket UI, seeded analyst list endpoint |
| SLA timers and escalation | `SlaService`, deadline columns, `SlaEscalationWorker`, dashboard compliance |
| Resolution tracking | status, response/resolution timestamps, resolution text, comments |
| Recurring/root-cause detection | deterministic fingerprint plus 30-day cluster endpoint |
| Major incident dashboard | commander, impact, severity, live duration, updates, communication visibility |
| Change risk/impact/approval/rollback | `ChangeRequest`, validation, role-gated decision, rollback readiness |
| CAB and conflicts | `CabMeeting`, pairwise overlap route, warning and checklist UI |
| Entra/M365 administration | `DirectoryUser`, `GraphSimulationService`, user operations console |
| Password/access/group/licence | reset flag, account enablement, group and licence allow-listed operations |
| Teams/SharePoint/Exchange scenarios | seeded tickets, major incident, service categories, knowledge articles |
| Server/VM/network/endpoint monitoring | polymorphic resource type, telemetry, health thresholds, alerts |
| PowerShell automation | four documented scripts using the same authenticated API |
| Service performance | open/P1/MI, SLA, MTTR, breach, health, demand KPIs |
| Searchable knowledge/training | server and client search, content, tags, authors, views |
| RBAC and complete audit | JWT roles/policies, UI guard, mutation history and admin audit table |

## 8. Run instructions

### Recommended: Docker

Prerequisites: Docker Desktop 4.x+ with Compose.

```bash
cp .env.example .env
docker compose up --build
```

Open the console at `http://localhost:3000`, Swagger at `http://localhost:8080/swagger`, and readiness at `http://localhost:8080/health`. Stop with `docker compose down`. To deliberately delete only this project's database volume and restore seed data, use `docker compose down -v`.

### Local development

Prerequisites: .NET 8 SDK, Node 22+, npm, and PostgreSQL 16.

1. Create database `serviceops` and match the connection in `src/api/appsettings.json`.
2. Run `dotnet run --project src/api/ServiceOps.Api.csproj`.
3. In another terminal run `cd src/web`, `npm install`, and `npm run dev`.
4. Open `http://localhost:5173`. Vite forwards API traffic to port 8080.

### Tests

```bash
dotnet test tests/ServiceOps.Tests/ServiceOps.Tests.csproj
cd src/web
npm install
npm run build
```

The production TypeScript build is a compile-time UI test. xUnit verifies SLA, escalation, recurrence fingerprinting, and change-window conflict rules.

### PowerShell automation

```powershell
$session = ./scripts/Connect-ServiceOps.ps1
./scripts/Get-ServiceHealth.ps1 -Session $session -Refresh
./scripts/New-ServiceOpsTicket.ps1 -Session $session `
  -Title "Outlook cannot connect" -Description "Desktop client disconnected" `
  -Category "Exchange Online" -Priority P2 -Requester "employee@contoso.demo"
```

Find a directory ID through `Invoke-RestMethod "$($session.ApiUrl)/api/directory/users" -Headers $session.Headers`, then run:

```powershell
./scripts/Invoke-M365SupportOperation.ps1 -Session $session `
  -DirectoryUserId <GUID> -Operation reset-password -WhatIf
```

Remove `-WhatIf` to execute the local simulation.

## 9. Demonstration script for an interview

1. Sign in as the administrator and explain that the seeded command center is live operational state, not static mockup data.
2. Point out open/P1 count, SLA compliance, active major incidents, MTTR, and demand by service.
3. Create a P2 Exchange Online ticket and explain automatic response/resolution targets.
4. Open Major Incidents and explain commander ownership, business impact, evidence timeline, and 30-minute communications.
5. Show Change & CAB: risk, implementation/test/rollback plans, conflict detection, and separate approval role.
6. In M365 Administration, reset a password or assign Power BI Pro. Emphasize the safe `IGraphSimulationService` boundary.
7. Open Infrastructure, run a telemetry poll, and connect WAN latency to the Teams voice incident.
8. Search the Teams knowledge article to demonstrate incident-to-knowledge improvement.
9. Open Audit Log and show the recorded Graph action with actor and entity.
10. Finish in Swagger or PowerShell to demonstrate the same platform is automation-ready.

## 10. Current scope and deliberate extensions

This is a complete runnable portfolio system, not a claim of production ITIL certification. The most valuable next extensions are Entra OIDC, real Graph behind managed identity and approval gates, EF migrations, business-hours/holiday SLA calendars, notifications, attachments, problem records and known errors, CMDB relationships, OpenTelemetry, Azure Monitor ingestion, SignalR live incident updates, granular permissions, and database-backed audit immutability.

The interfaces keep those extensions clean: replace `IGraphSimulationService` with a production Graph adapter; replace the telemetry simulation with Azure Monitor/Prometheus collectors; expand `ISlaService` with a working-calendar provider; emit domain events from endpoints to notification and audit consumers.
