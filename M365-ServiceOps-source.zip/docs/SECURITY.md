# Security model and production hardening

## Implemented controls

- JWT authentication with issuer, audience, signature, expiration, and one-minute clock-skew validation.
- Passwords stored with ASP.NET Identity's versioned password hasher; plaintext passwords are never persisted.
- Role policies separate Viewer, Analyst, Change Manager, and Administrator capabilities.
- Microsoft Graph operations are simulations and cannot contact a tenant.
- Directory endpoints never expose password material.
- Administrative audit access is isolated by policy.
- Mutating ticket and directory operations record actor, action, entity, details, source IP, and timestamp.
- API errors use a stable response and trace identifier instead of returning stack traces.
- PostgreSQL is not exposed to the host in Docker Compose.

## Before production

Replace the demo JWT key with a secret from Azure Key Vault. Replace local authentication with Microsoft Entra OpenID Connect and Conditional Access. Use EF migrations rather than `EnsureCreated`. Restrict CORS to the deployed web origin. Add rate limiting, anti-forgery protection if cookies replace bearer tokens, TLS termination, structured security logging, retention policies, database encryption and backup. Separate operational and audit databases or use append-only/WORM retention. Validate all change transitions as a state machine. Add Graph managed identity with least-privilege application permissions and an approval gate before live changes. Run dependency, container, SAST and DAST scans. Remove demo accounts and seed data.

## Roles

| Role | Read | Work tickets/incidents | Change submission/decision | Directory simulation | Audit |
|---|---:|---:|---:|---:|---:|
| Viewer | Yes | No | No | No | No |
| Analyst | Yes | Yes | No | Yes | No |
| ChangeManager | Yes | Yes | Yes | Yes | No |
| Admin | Yes | Yes | Yes | Yes | Yes |
