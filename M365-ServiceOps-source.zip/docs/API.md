# API reference

All routes except login and health require `Authorization: Bearer <JWT>`. Enum values are JSON strings. Swagger provides an interactive contract at `/swagger`.

| Method | Route | Minimum role | Purpose |
|---|---|---|---|
| POST | `/api/auth/login` | Public | Authenticate and return an eight-hour JWT. |
| GET | `/api/dashboard` | Viewer | Aggregate operational KPIs and ticket demand. |
| GET/POST | `/api/tickets/` | Viewer / Operator | Search or submit tickets. |
| GET/PUT | `/api/tickets/{id}` | Viewer / Operator | Read or transition a ticket. |
| POST | `/api/tickets/{id}/comments` | Operator | Add work notes or customer-visible comments. |
| GET | `/api/tickets/analytics/recurring` | Viewer | Return 30-day fingerprint clusters with at least two tickets. |
| GET/POST | `/api/major-incidents/` | Viewer / Operator | List or declare major incidents. |
| POST | `/api/major-incidents/{id}/updates` | Operator | Append a status/timeline update. |
| GET/POST | `/api/changes/` | Viewer / Change Manager | List or submit changes. |
| GET | `/api/changes/conflicts` | Viewer | Find overlapping change windows. |
| POST | `/api/changes/{id}/decision` | Change Manager | Record CAB approval/rejection. |
| GET | `/api/cab-meetings` | Viewer | Show CAB schedule, chair, attendees, and agenda. |
| GET | `/api/directory/users` | Viewer | Search simulated Entra directory users. |
| POST | `/api/directory/users/{id}/operations` | Operator | Reset password, enable/disable, alter groups or licences. |
| GET | `/api/monitoring/resources` | Viewer | Read infrastructure telemetry. |
| GET | `/api/monitoring/alerts` | Viewer | Read current alert queue. |
| POST | `/api/monitoring/alerts/{id}/acknowledge` | Operator | Acknowledge an alert. |
| POST | `/api/monitoring/simulate-poll` | Operator | Generate a new safe telemetry sample. |
| GET/POST | `/api/knowledge/` | Viewer / Operator | Search or publish articles. |
| GET | `/api/knowledge/{id}` | Viewer | Read and increment article views. |
| GET | `/api/audit` | Administrator | Read the immutable operational audit trail. |
| GET | `/api/users` | Viewer | Return safe user assignment data without password hashes. |
| GET | `/health` | Public | Database-aware readiness check. |

## Example ticket request

```json
{
  "title": "Outlook cannot connect",
  "description": "Desktop client has been disconnected for 20 minutes.",
  "category": "Exchange Online",
  "priority": "P2",
  "requesterEmail": "employee@contoso.demo"
}
```

## Error format

Unhandled domain errors return `{ "error": "message", "traceId": "..." }`. Validation errors use ASP.NET `ValidationProblemDetails`. Clients should log the trace ID, not secrets or bearer tokens.
